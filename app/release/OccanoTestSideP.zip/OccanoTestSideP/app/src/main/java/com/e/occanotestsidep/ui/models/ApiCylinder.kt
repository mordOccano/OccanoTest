package com.e.occanotestsidep.ui.models

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize


@Parcelize
@Entity(tableName = "api_cylinder")
data class ApiCylinder(
    @PrimaryKey
    @ColumnInfo(name = "cylinder_num")
    var numOfCylInEngine: Int = 0,

    @ColumnInfo(name = "cylinder_details")
    var dashboard: Dashboard? = null
) : Parcelable {
    override fun equals(other: Any?): Boolean {
        return super.equals(other)
    }

    override fun hashCode(): Int {
        return super.hashCode()
    }
}