package com.e.occanotestsidep.persistence.asyncCyl;

import android.os.AsyncTask;

import com.e.occanosidetest.models.GaugeForCalibration;
import com.e.occanotestsidep.persistence.CylinderDao;
import com.e.occanotestsidep.ui.models.Cylinder;


public class DeleteAsyncTask extends AsyncTask<Cylinder, Void, Void> {

    private CylinderDao calibDao;

    public DeleteAsyncTask(CylinderDao dao) {
        calibDao = dao;
    }


    @Override
    protected Void doInBackground(Cylinder... cylinders) {
        calibDao.delete(cylinders);
        return null;
    }
}
