package com.e.occanotestsidep.persistence;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.e.occanosidetest.models.GaugeForCalibration;
import com.e.occanosidetest.models.Log;
import com.e.occanotestsidep.ui.models.Cylinder;

import java.util.List;

@Dao
public interface CylinderDao {

    @Insert
    long[] insertCyls(Cylinder... cylinders);

    @Query("SELECT * FROM cylinders")
    LiveData<List<Cylinder>> getCylinders();

//    @Query("SELECT * FROM cylinders WHERE id = :id")
//    List<Log> getCylindersWithCustomQuery(int id);

//    @Query("SELECT * FROM logs WHERE content LIKE :content")
//    List<Log> getLogWithCustomLikeQuery(String content);

    @Delete
    int delete(Cylinder... cylinders);

    @Update
    int update(Cylinder... cylinders);
}
