package com.e.occanotestsidep.persistence.asyncCyl;


import android.os.AsyncTask;

import com.e.occanotestsidep.persistence.CylinderDao;
import com.e.occanotestsidep.ui.models.Cylinder;

public class InsertAsyncTask extends AsyncTask<Cylinder, Void, Void> {

    private CylinderDao calibDao;

    public InsertAsyncTask(CylinderDao dao) {
        calibDao = dao;
    }


    @Override
    protected Void doInBackground(Cylinder... cylinders) {
        calibDao.insertCyls(cylinders);
        return null;
    }
}
