package com.e.occanotestsidep.ui.main.dashboard.state

import com.e.occanotestsidep.ui.models.Cylinder
import com.e.occanotestsidep.ui.models.DashMetaData
import com.google.gson.JsonObject

data class DashboardViewState(
    var cylinders: List<Cylinder>? = null,
    var metadata: DashMetaData?= null
)