package com.e.occanotestsidep.repository

import androidx.lifecycle.LiveData
import com.e.occanotestsidep.api.MyRetrofitBuilder
import com.e.occanotestsidep.ui.main.dashboard.state.DashboardViewState
import com.e.occanotestsidep.ui.models.Cylinder
import com.e.occanotestsidep.utils.ApiSuccessResponse
import com.e.occanotestsidep.utils.DataState
import com.e.occanotestsidep.utils.GenericApiResponse

object Repository {

    fun getCylinders(): LiveData<DataState<DashboardViewState>> {
        return object: NetworkBoundResource<List<Cylinder>, DashboardViewState>(){

            override fun handleApiSuccessResponse(response: ApiSuccessResponse<List<Cylinder>>) {
                result.value = DataState.data(
                    null,
                    DashboardViewState(
                        cylinders = response.body
                    )
                )
            }

            override fun createCall(): LiveData<GenericApiResponse<List<Cylinder>>> {
                return MyRetrofitBuilder.apiService.getCylinders()
            }

        }.asLiveData()
    }

}
