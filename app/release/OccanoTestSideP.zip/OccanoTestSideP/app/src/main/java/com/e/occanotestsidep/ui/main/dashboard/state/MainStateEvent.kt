package com.e.occanotestsidep.ui.main.dashboard.state

sealed class MainStateEvent {

    class GetReportForDashboardEvent: MainStateEvent()
//
//    class GetUserEvent(
//        val userId: String
//    ): MainStateEvent()

    class None: MainStateEvent()
}