package com.e.occanotestsidep.persistence;

import android.content.Context;

import androidx.lifecycle.LiveData;

import com.e.occanotestsidep.persistence.asyncCyl.DeleteAsyncTask;
import com.e.occanotestsidep.persistence.asyncCyl.InsertAsyncTask;
import com.e.occanotestsidep.persistence.asyncCyl.UpdateAsyncTask;
import com.e.occanotestsidep.ui.models.Cylinder;


import java.util.List;

public class CylsRepository {

    private AppDatabase appDatabase;


    public CylsRepository(Context context){
        appDatabase = AppDatabase.getInstance(context);
    }

    public void insertCylTask(Cylinder Cyl){
        new InsertAsyncTask(appDatabase.getCylDao()).execute(Cyl);
    }

    public void updateCyl(Cylinder cyl){
        new UpdateAsyncTask(appDatabase.getCylDao()).execute(cyl);

    }

    public LiveData<List<Cylinder>> retriveCylTask(){
        return appDatabase.getCylDao().getCylinders();
    }

    public void deleteCyl(Cylinder cyl){
        new DeleteAsyncTask(appDatabase.getCylDao()).execute(cyl);
    }
}
